# Raw and intermediate simulation results

This directory contains the intermediate simulation results based on the
pre-registered and the tweaked simulation study. Running the commands `make
partial-repro` and `make figure-repro` from the root directory of this
repository will use these data to produce figure 2 from the paper and the six
figures from the supplementary material.
