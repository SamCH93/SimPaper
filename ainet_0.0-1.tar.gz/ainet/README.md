# Pitfalls and Potentials in Simulation Studies

##  The `ainet` package

This GitHub repository accompanies the arXiv preprint
[arXiv:2203.13076](https://arxiv.org/abs/2203.13076).

Install `ainet` via
```r
remotes::install_github("LucasKook/ainet")
```

For more information, please visit the [main
repository](https://github.com/SamCH93/SimPaper).
